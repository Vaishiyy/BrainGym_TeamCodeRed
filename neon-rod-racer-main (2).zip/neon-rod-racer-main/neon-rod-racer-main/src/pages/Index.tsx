import ArcadeGame from '@/game/ArcadeGame';

const Index = () => <ArcadeGame />;

export default Index;
