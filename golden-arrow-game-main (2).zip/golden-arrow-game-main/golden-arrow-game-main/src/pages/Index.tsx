import GridLogicGame from "@/components/GridLogicGame";

const Index = () => <GridLogicGame />;

export default Index;
