import GameScreen from '@/components/game/GameScreen';

const Index = () => {
  return <GameScreen />;
};

export default Index;
